//
//  AppDelegate.h
//  TF_manPickerView
//
//  Created by TF_man on 16/5/11.
//  Copyright © 2016年 TF_man. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

