//
//  AppDelegate.h
//  CATransition
//
//  Created by TravelRound on 15/12/7.
//  Copyright © 2015年 TravelRound. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

