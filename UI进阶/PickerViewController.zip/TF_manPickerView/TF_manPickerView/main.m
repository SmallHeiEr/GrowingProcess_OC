//
//  main.m
//  TF_manPickerView
//
//  Created by 体团网 on 16/5/11.
//  Copyright © 2016年 TF_man. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
