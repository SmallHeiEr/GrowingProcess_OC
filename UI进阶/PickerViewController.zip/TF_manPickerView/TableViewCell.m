//
//  TableViewCell.m
//  TF_manPickerView
//
//  Created by TF_man on 16/5/11.
//  Copyright © 2016年 TF_man. All rights reserved.
//

#import "TableViewCell.h"

@implementation TableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
