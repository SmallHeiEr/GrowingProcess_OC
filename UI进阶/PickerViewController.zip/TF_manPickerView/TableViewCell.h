//
//  TableViewCell.h
//  TF_manPickerView
//
//  Created by TF_man on 16/5/11.
//  Copyright © 2016年 TF_man. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *leftLb;

@property (weak, nonatomic) IBOutlet UILabel *rightLb;


@end
